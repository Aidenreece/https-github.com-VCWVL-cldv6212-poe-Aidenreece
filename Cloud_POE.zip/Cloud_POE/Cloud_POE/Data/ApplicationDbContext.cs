﻿using Microsoft.EntityFrameworkCore;
using Cloud_POE.Models;
using System.Collections.Generic;

namespace Cloud_POE.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<FileModel> Files { get; set; }
        public DbSet<ContactUsModel> Contacts { get; set; }

        // Configure the model
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure the 'Amount' property of the 'Order' entity
            modelBuilder.Entity<Order>()
                .Property(o => o.Amount)
                .HasColumnType("decimal(18, 2)")  // Precision: 18, Scale: 2
                .IsRequired();  // Ensures the field is required

            // You can configure other entities here as well
        }
    }
}
