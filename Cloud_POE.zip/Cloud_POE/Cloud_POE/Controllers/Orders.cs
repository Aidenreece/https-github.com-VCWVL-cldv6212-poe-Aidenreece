﻿using Cloud_POE.Models;
using Cloud_POE.Data;  // Import the DbContext for SQL interaction
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cloud_POE.Controllers
{
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext _context;  // Use ApplicationDbContext for SQL interaction

        public OrdersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Orders (Order Creation Form)
        public async Task<IActionResult> Index()
        {
            // Fetch lists of customers and products to display in the form's dropdowns
            ViewBag.Customers = await _context.Customers.ToListAsync();
            ViewBag.Products = await _context.Products.ToListAsync();

            return View();
        }

        // POST: Orders (Submit Order)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(Order model)
        {
            // Handle the form submission to create a new order
            if (ModelState.IsValid)
            {
                try
                {
                    // Add the order to the database
                    _context.Orders.Add(model);
                    await _context.SaveChangesAsync();

                    // Return success message after order creation
                    ViewData["Message"] = "Order has been submitted successfully.";
                    return View();
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error while submitting the order: {ex.Message}");
                }
            }

            // Return the view with validation errors if any
            return View(model);
        }

        // GET: View Orders (Display All Orders)
        public async Task<IActionResult> ViewOrders()
        {
            // Retrieve all orders, including related customer and product details
            var orders = await _context.Orders
                .Include(o => o.Customer)  // Include customer details
                .Include(o => o.Product)   // Include product details
                .ToListAsync();

            return View(orders);
        }
    }
}
