﻿using Microsoft.AspNetCore.Mvc;
using Cloud_POE.Models;
using Cloud_POE.Data;  // Import the DbContext namespace
using System.Threading.Tasks;

namespace Cloud_POE.Controllers
{
    public class ContactUsController : Controller
    {
        private readonly ApplicationDbContext _context; // Add DbContext for database interaction

        public ContactUsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(ContactUsModel model)
        {
            if (ModelState.IsValid)
            {
                // Save feedback to the database
                _context.Contacts.Add(model);  // Add the contact message to the database
                await _context.SaveChangesAsync(); // Save changes asynchronously

                ViewData["Message"] = "Customer Feedback Noted";
                return View();
            }

            return View(model);
        }
    }
}
