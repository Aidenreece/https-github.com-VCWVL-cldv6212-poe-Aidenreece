﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Cloud_POE.Models;

namespace Cloud_POE.Controllers
{
    [Route("[controller]")]  
    public class FilesController : Controller
    {
        private readonly string _fileDirectory = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles");

        public FilesController()
        {
            // Ensure the directory exists
            if (!Directory.Exists(_fileDirectory))
            {
                Directory.CreateDirectory(_fileDirectory);
            }
        }

        // GET: /Files
        [HttpGet("")]
        public IActionResult Index()
        {
            var files = Directory.GetFiles(_fileDirectory)
                                 .Select(filePath => new FileModel
                                 {
                                     FileName = Path.GetFileName(filePath),
                                     FileSize = new FileInfo(filePath).Length,
                                     UploadDate = System.IO.File.GetLastWriteTime(filePath)
                                 })
                                 .ToList();

            return View(files);
        }

        // GET: /Files/Upload
        [HttpGet("Upload")]
        public IActionResult Upload()
        {
            return View();
        }

        // POST: /Files/Upload
        [HttpPost("Upload")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                var filePath = Path.Combine(_fileDirectory, file.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                TempData["Message"] = "File uploaded successfully!";
            }
            else
            {
                TempData["Message"] = "No file selected!";
            }

            return RedirectToAction(nameof(Index));  // Redirect to Index after uploading
        }

        // GET: /Files/Download/{fileName}
        [HttpGet("Download/{fileName}")]
        public IActionResult Download(string fileName)
        {
            var filePath = Path.Combine(_fileDirectory, fileName);

            if (System.IO.File.Exists(filePath))
            {
                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                var fileType = "application/octet-stream"; // Adjust MIME type as needed

                return File(fileBytes, fileType, fileName);
            }

            return NotFound();
        }

        // POST: /Files/Delete
        [HttpPost("Delete")]
        public IActionResult Delete(string fileName)
        {
            var filePath = Path.Combine(_fileDirectory, fileName);

            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
                TempData["Message"] = "File deleted successfully!";
            }
            else
            {
                TempData["Message"] = "File not found!";
            }

            return RedirectToAction(nameof(Index));  // Redirect to Index after deleting
        }
    }
}
