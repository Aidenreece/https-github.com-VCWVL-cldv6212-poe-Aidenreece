﻿using Cloud_POE.Models;
using Cloud_POE.Data;  // Add ApplicationDbContext
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Cloud_POE.Controllers
{
    [Route("[controller]")]
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context; // Use the DbContext for SQL interaction

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Products/Index
        [HttpGet]
        [Route("Index")]
        public async Task<IActionResult> Index()
        {
            var productsList = await _context.Products.ToListAsync(); // Retrieve products from SQL database
            return View(productsList);
        }

        // GET: /Products/Create
        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Products/Create
        [HttpPost]
        [Route("Create")]
        public async Task<IActionResult> Create(Product product, IFormFile imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                // Generate a unique filename
                var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", uniqueFileName);

                // Save the image file locally
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(stream);
                }

                // Set the image URL (this could be a relative path if hosted in a static file folder)
                product.ImageUrl = $"/images/{uniqueFileName}";
            }

            if (ModelState.IsValid)
            {
                // Add product to the SQL database
                _context.Products.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(product);
        }

        // POST: /Products/Delete
        [HttpPost]
        [Route("DeleteConfirmed")]
        public async Task<IActionResult> DeleteConfirmed(int productId)
        {
            var product = await _context.Products.FindAsync(productId);

            if (product == null)
            {
                return NotFound();
            }

            // Delete the product's image if it exists
            if (!string.IsNullOrEmpty(product.ImageUrl))
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", product.ImageUrl.TrimStart('/'));
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath); // Delete the image file from the local directory
                }
            }

            // Remove product from the database
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
