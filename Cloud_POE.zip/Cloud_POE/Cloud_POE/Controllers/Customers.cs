﻿using Microsoft.AspNetCore.Mvc;
using Cloud_POE.Data;  // Import the DbContext namespace
using Cloud_POE.Models;  // Import the Customer model
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;  // For EF Core functionality

namespace Cloud_POE.Controllers
{
    [Route("[controller]")]
    public class CustomersController : Controller
    {
        private readonly ApplicationDbContext _context;  // Use ApplicationDbContext for SQL interaction

        public CustomersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Customers
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            // Get the list of customers from the database using Entity Framework
            var customersList = await _context.Customers.ToListAsync();
            return View(customersList);
        }

        // GET: /Customers/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Customers/Create
        [HttpPost("Create")]
        public async Task<IActionResult> Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Add the new customer to the database
                    _context.Customers.Add(customer);
                    await _context.SaveChangesAsync();  // Save changes to the database
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    // Handle the exception (e.g., log it and return an error view)
                    ModelState.AddModelError("", "Unable to save changes. Please try again.");
                }
            }

            return View(customer);
        }

        // POST: /Customers/DeleteConfirmed
        [HttpPost("DeleteConfirmed")]
        public async Task<IActionResult> DeleteConfirmed(int customerId)
        {
            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null)
            {
                return NotFound();
            }

            try
            {
                _context.Customers.Remove(customer);  // Remove the customer from the database
                await _context.SaveChangesAsync();  // Save changes to the database
            }
            catch (Exception ex)
            {
                // Handle the exception (e.g., log it and return an error view)
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while deleting the customer.");
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
