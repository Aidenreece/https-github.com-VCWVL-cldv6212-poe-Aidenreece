﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Cloud_POE.Models
{
    public class Customer
    {
        [Key]
        public int CustomerId { get; set; }  // Primary key for SQL

        [Required]
        [StringLength(100, MinimumLength = 1)]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
