﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Cloud_POE.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }  // Primary key for SQL

        [Required]
        public int CustomerId { get; set; }  // Foreign key referencing Customer

        [Required]
        public int ProductId { get; set; }  // Foreign key referencing Product

        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Amount must be a positive number.")]
        public decimal Amount { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        // Navigation properties
        public Customer Customer { get; set; }
        public Product Product { get; set; }
    }
}
