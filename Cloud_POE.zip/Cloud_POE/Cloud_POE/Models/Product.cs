﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Cloud_POE.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }  // Primary key for SQL

        [Required]
        [StringLength(100, MinimumLength = 1)]
        public string Name { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be a positive value.")]
        public double Price { get; set; }

        public string? ImageUrl { get; set; }  // The URL of the product image

        [Required]
        public string Description { get; set; }
    }
}
