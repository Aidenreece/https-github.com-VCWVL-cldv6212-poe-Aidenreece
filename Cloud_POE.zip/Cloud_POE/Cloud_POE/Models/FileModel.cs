﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Cloud_POE.Models
{
    public class FileModel
    {
        [Key]
        public int FileId { get; set; }  // Primary key for SQL

        [Required]
        public string FileName { get; set; }

        [Required]
        public string FileType { get; set; }

        public long FileSize { get; set; }
        public DateTime UploadDate { get; set; }

        // Computed property for display
        public string DisplaySize
        {
            get
            {
                if (FileSize >= 1024 * 1024)
                    return $"{FileSize / 1024 / 1024} MB";
                if (FileSize >= 1024)
                    return $"{FileSize / 1024} KB";
                return $"{FileSize} Bytes";
            }
        }
    }
}
